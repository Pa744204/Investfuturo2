function mostrarContato() {
  const contato = document.getElementById("contato");
  contato.classList.toggle("hidden");
}